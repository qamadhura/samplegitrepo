package Scripts;

import org.openqa.selenium.WebDriver;

public class NeovaDemo {
	WebDriver driver;
	public void invokeBrowser() {
		
	}
	public void searchElement() {
		//ul[@id='menu-main-menu']//li//a
		//ul[@id='menu-main-menu']//li[position()>2 and position()<9]//a
		//*[@class='footer-bottom']//*[@class='f-b']
		//*[@class='owl-wrapper-outer']//a//img
		//*[@class='progress']//span[text()='90%']
		//a//i[@class='vc_tta-icon fa fa-thumbs-up']
		//span[text()='Sr Software Engineer - Asp.Net with AngularJS - 5+Yrs - Pune']//..//i
		//8 //*[@class='feature-icon ']//i
		//9 //*[@class='team-content']//a[contains(@href,'http://www.neovasolutions.com/index.php/team_member')]
		//10 //i[@class='fa fa-star']
	}
	public void scrollToElement() {
		
	}
	public static void main(String[] args) {

	}

}
